//! Challenge solver trait and built-in implementations.
//!
//! Implement [`ChallengeSolver`] for custom challenge types.  Two built-in
//! helpers handle the common cases:
//!
//! - [`Http01Solver`] — serves `/.well-known/acme-challenge/<token>` on a
//!   local TCP port (default 80) using a minimal hyper HTTP/1.1 server.
//! - [`Dns01Helper`] — computes the TXT record value; DNS provisioning is the
//!   caller's responsibility.
//! - [`DnsPersist01Helper`] — same math as `Dns01Helper`.

use std::{
    collections::HashMap,
    net::SocketAddr,
    sync::{Arc, RwLock},
};

use http_body_util::Full;
use hyper::{body::Bytes, server::conn::http1, service::service_fn, Request, Response};
use hyper_util::rt::TokioIo;
use tokio::net::TcpListener;

use crate::{account::dns_txt_value, error::ClientError};

/// Async trait for challenge solvers.
///
/// `present` is called before the client triggers the challenge; `cleanup` is
/// called after the challenge completes (success or failure).
pub trait ChallengeSolver: Send + Sync {
    fn present(
        &self,
        token: &str,
        key_auth: &str,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<(), ClientError>> + Send + '_>>;

    fn cleanup(
        &self,
        token: &str,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<(), ClientError>> + Send + '_>>;
}

// ── http-01 solver ────────────────────────────────────────────────────────────

type TokenStore = Arc<RwLock<HashMap<String, String>>>;

/// Serves `/.well-known/acme-challenge/<token>` via a minimal HTTP/1.1 server.
///
/// Binds to the given port on `127.0.0.1`.  In production, port 80 must be
/// used (or an upstream proxy must forward the ACME challenge path).
pub struct Http01Solver {
    port: u16,
    store: TokenStore,
}

impl Http01Solver {
    pub fn new(port: u16) -> Self {
        Http01Solver {
            port,
            store: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    /// Bind the TCP listener and spawn the accept loop in the background.
    ///
    /// Call this once before issuing any orders.
    pub async fn start(&self) -> Result<(), ClientError> {
        let addr = SocketAddr::from(([0, 0, 0, 0], self.port));
        let listener = TcpListener::bind(addr).await?;
        let store = Arc::clone(&self.store);
        tokio::spawn(async move {
            loop {
                let Ok((stream, _)) = listener.accept().await else {
                    continue;
                };
                let io = TokioIo::new(stream);
                let store = Arc::clone(&store);
                tokio::spawn(async move {
                    let _ = http1::Builder::new()
                        .serve_connection(
                            io,
                            service_fn(move |req: Request<hyper::body::Incoming>| {
                                let store = Arc::clone(&store);
                                async move { handle_challenge(&store, req) }
                            }),
                        )
                        .await;
                });
            }
        });
        Ok(())
    }
}

fn handle_challenge(
    store: &TokenStore,
    req: Request<hyper::body::Incoming>,
) -> Result<Response<Full<Bytes>>, std::convert::Infallible> {
    const PREFIX: &str = "/.well-known/acme-challenge/";
    let path = req.uri().path();
    if let Some(token) = path.strip_prefix(PREFIX) {
        let body = store
            .read()
            .unwrap()
            .get(token)
            .cloned()
            .unwrap_or_default();
        Ok(Response::new(Full::new(Bytes::from(body))))
    } else {
        Ok(Response::builder()
            .status(404)
            .body(Full::new(Bytes::new()))
            .unwrap())
    }
}

impl ChallengeSolver for Http01Solver {
    fn present(
        &self,
        token: &str,
        key_auth: &str,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<(), ClientError>> + Send + '_>>
    {
        let token = token.to_owned();
        let key_auth = key_auth.to_owned();
        let store = Arc::clone(&self.store);
        Box::pin(async move {
            store.write().unwrap().insert(token, key_auth);
            Ok(())
        })
    }

    fn cleanup(
        &self,
        token: &str,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<(), ClientError>> + Send + '_>>
    {
        let token = token.to_owned();
        let store = Arc::clone(&self.store);
        Box::pin(async move {
            store.write().unwrap().remove(&token);
            Ok(())
        })
    }
}

// ── dns-01 helper ─────────────────────────────────────────────────────────────

/// Computes the `_acme-challenge.<domain>` TXT record value for dns-01.
///
/// The caller is responsible for provisioning and removing the DNS record.
pub struct Dns01Helper;

impl Dns01Helper {
    /// Returns `base64url(SHA-256(key_authorization))`.
    pub fn txt_value(key_auth: &str) -> Result<String, ClientError> {
        dns_txt_value(key_auth)
    }
}

// ── dns-persist-01 helper ─────────────────────────────────────────────────────

/// Computes the persistent TXT record value for dns-persist-01.
///
/// Uses the same SHA-256 digest as dns-01 (per the LE draft).  The caller is
/// responsible for provisioning the long-lived `_validation-persist.<domain>`
/// TXT record before placing the order.
pub struct DnsPersist01Helper;

impl DnsPersist01Helper {
    /// Returns `base64url(SHA-256(key_authorization))`.
    pub fn txt_value(key_auth: &str) -> Result<String, ClientError> {
        dns_txt_value(key_auth)
    }
}

// ── tls-alpn-01 solver ────────────────────────────────────────────────────────

/// SNI-based certificate resolver: looks up the per-domain certified key in the
/// shared store.
#[derive(Debug)]
struct SniResolver {
    certs: Arc<RwLock<HashMap<String, Arc<rustls::sign::CertifiedKey>>>>,
}

impl rustls::server::ResolvesServerCert for SniResolver {
    fn resolve(
        &self,
        client_hello: rustls::server::ClientHello<'_>,
    ) -> Option<Arc<rustls::sign::CertifiedKey>> {
        let sni = client_hello.server_name()?;
        let certs = self.certs.read().ok()?;
        certs.get(sni).cloned()
    }
}

/// Serves ephemeral ACME challenge certificates for tls-alpn-01 (RFC 8737).
///
/// Call [`start`](TlsAlpn01Solver::start) once to bind the port, then call
/// [`present`](TlsAlpn01Solver::present) for each domain/challenge pair before
/// triggering the challenge at the ACME server.  When finished, call
/// [`cleanup`](TlsAlpn01Solver::cleanup) to abort the background listener.
pub struct TlsAlpn01Solver {
    port: u16,
    certs: Arc<RwLock<HashMap<String, Arc<rustls::sign::CertifiedKey>>>>,
    handle: Option<tokio::task::JoinHandle<()>>,
}

impl TlsAlpn01Solver {
    /// Create a new solver that will listen on `port` (typically 443).
    pub fn new(port: u16) -> Self {
        TlsAlpn01Solver {
            port,
            certs: Arc::new(RwLock::new(HashMap::new())),
            handle: None,
        }
    }

    /// Bind the TCP port and start the TLS accept loop.
    ///
    /// The loop accepts connections and completes TLS handshakes (ALPN
    /// `acme-tls/1`) so that the ACME server can fetch the challenge cert via
    /// SNI.  Call this once before the first [`present`](Self::present).
    pub async fn start(&mut self) -> Result<(), ClientError> {
        let config = rustls::ServerConfig::builder_with_provider(Arc::new(
            rustls::crypto::ring::default_provider(),
        ))
        .with_safe_default_protocol_versions()
        .map_err(|e| ClientError::Crypto(format!("rustls: {e}")))?
        .with_no_client_auth()
        .with_cert_resolver(Arc::new(SniResolver {
            certs: Arc::clone(&self.certs),
        }));

        let mut config = config;
        config.alpn_protocols = vec![b"acme-tls/1".to_vec()];

        let listener = tokio::net::TcpListener::bind(("0.0.0.0", self.port)).await?;

        self.handle = Some(tokio::spawn(async move {
            let acceptor = tokio_rustls::TlsAcceptor::from(Arc::new(config));
            loop {
                if let Ok((stream, _)) = listener.accept().await {
                    let acc = acceptor.clone();
                    tokio::spawn(async move {
                        let _ = acc.accept(stream).await;
                    });
                }
            }
        }));

        Ok(())
    }

    /// Generate and register the challenge certificate for `domain`.
    ///
    /// * `domain`   — the ACME identifier value (DNS name or IP string).
    /// * `id_type`  — `"dns"` or `"ip"`.
    /// * `key_auth` — `{token}.{jwk_thumbprint}`.
    pub async fn present(
        &self,
        domain: &str,
        id_type: &str,
        key_auth: &str,
    ) -> Result<(), ClientError> {
        use synta_certificate::{
            acme_types::Authorization, default_data_hasher, oids, parse_time, BackendPrivateKey,
            CertificateBuilder, DataHasher, NameBuilder, PrivateKey as _,
            SubjectAlternativeNameBuilder,
        };

        // 1. Compute SHA-256(key_auth) → 32 bytes.
        let hash: [u8; 32] = default_data_hasher()
            .hash_data("sha256", key_auth.as_bytes())
            .map_err(|e| ClientError::Crypto(format!("SHA-256: {e}")))?
            .try_into()
            .map_err(|_| ClientError::Crypto("SHA-256 did not return 32 bytes".into()))?;

        // 2. Build the id-pe-acmeIdentifier extension value:
        //    OCTET STRING { <32-byte hash> } encoded as DER → 04 20 <hash>.
        let auth = Authorization::new_unchecked(synta::OctetString::new(hash.to_vec()));
        let ext_value = auth
            .to_der()
            .map_err(|e| ClientError::Crypto(format!("encode acme ext: {e}")))?;

        // 3. Generate an ephemeral EC P-256 key pair.
        let key = BackendPrivateKey::generate_ec("P-256")
            .map_err(|e| ClientError::Crypto(format!("generate key: {e}")))?;

        // 4. Extract SPKI (for cert) and PKCS#8 DER (for rustls).
        let spki = key
            .public_key()
            .map_err(|e| ClientError::Crypto(format!("public key: {e}")))?
            .spki_der()
            .to_vec();
        let pkcs8_der = key
            .to_der()
            .map_err(|e| ClientError::Crypto(format!("key to DER: {e}")))?;

        // 5. Build validity timestamps (not_before = now, not_after = now + 7 days).
        let now_secs = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs() as i64;
        let nb = parse_time(&unix_to_generalized_time(now_secs))
            .map_err(|e| ClientError::Crypto(format!("notBefore: {e}")))?;
        let na = parse_time(&unix_to_generalized_time(now_secs + 86400 * 7))
            .map_err(|e| ClientError::Crypto(format!("notAfter: {e}")))?;

        // 6. Build subject / issuer name.
        let name_der = NameBuilder::new()
            .common_name(domain)
            .build()
            .map_err(|e| ClientError::Crypto(format!("name: {e}")))?;

        // 7. Build SAN: iPAddress for "ip", dNSName otherwise.
        let san_der = if id_type == "ip" {
            let ip_bytes = if let Ok(v4) = domain.parse::<std::net::Ipv4Addr>() {
                v4.octets().to_vec()
            } else if let Ok(v6) = domain.parse::<std::net::Ipv6Addr>() {
                v6.octets().to_vec()
            } else {
                return Err(ClientError::Crypto(format!("invalid IP address: {domain}")));
            };
            SubjectAlternativeNameBuilder::new()
                .ip_address(&ip_bytes)
                .build()
                .map_err(|e| ClientError::Crypto(format!("SAN ip: {e}")))?
        } else {
            SubjectAlternativeNameBuilder::new()
                .dns_name(domain)
                .build()
                .map_err(|e| ClientError::Crypto(format!("SAN dns: {e}")))?
        };

        // 8. Build and sign the challenge certificate.
        let signer = key.as_signer("sha256");
        let cert_der = CertificateBuilder::new()
            .issuer_name(&name_der)
            .subject_name(&name_der)
            .public_key_der(&spki)
            .serial_number(synta::Integer::from_i64(1))
            .not_valid_before(nb)
            .not_valid_after(na)
            .add_extension_oid(oids::SUBJECT_ALT_NAME, false, &san_der)
            .add_extension_oid(oids::PE_ACME_IDENTIFIER, true, &ext_value)
            .sign(&signer)
            .map_err(|e| ClientError::Crypto(format!("sign cert: {e}")))?;

        // 9. Load the key and cert into a rustls CertifiedKey.
        let private_key = rustls::pki_types::PrivateKeyDer::Pkcs8(
            rustls::pki_types::PrivatePkcs8KeyDer::from(pkcs8_der),
        );
        let signing_key = rustls::crypto::ring::default_provider()
            .key_provider
            .load_private_key(private_key)
            .map_err(|e| ClientError::Crypto(format!("load key: {e}")))?;
        let cert_der_type = rustls::pki_types::CertificateDer::from(cert_der);
        let certified = Arc::new(rustls::sign::CertifiedKey::new(
            vec![cert_der_type],
            signing_key,
        ));

        // 10. Register in the SNI store.
        self.certs
            .write()
            .unwrap()
            .insert(domain.to_string(), certified);

        Ok(())
    }

    /// Abort the background TLS listener.
    pub fn cleanup(&mut self) {
        if let Some(h) = self.handle.take() {
            h.abort();
        }
    }
}

/// Convert Unix seconds to a GeneralizedTime string (`YYYYMMDDHHmmssZ`).
///
/// Mirrors `crate::ca::init::unix_to_generalized_time` in the server crate.
fn unix_to_generalized_time(secs: i64) -> String {
    let gt = synta::GeneralizedTime::from_unix(secs)
        .unwrap_or_else(|| synta::GeneralizedTime::from_unix(0).unwrap());
    format!(
        "{:04}{:02}{:02}{:02}{:02}{:02}Z",
        gt.year, gt.month, gt.day, gt.hour, gt.minute, gt.second
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn dns01_txt_value_is_base64url_sha256() {
        // key_auth = "token.thumbprint" — the TXT value is base64url(sha256(key_auth)).
        let key_auth = "sometoken.somethumbprint";
        let txt = Dns01Helper::txt_value(key_auth).unwrap();
        // Must be non-empty base64url.
        assert!(!txt.is_empty());
        assert!(!txt.contains('+'));
        assert!(!txt.contains('/'));
        assert!(!txt.contains('='));
    }

    #[test]
    fn dns_persist_01_matches_dns01() {
        let key_auth = "sometoken.somethumbprint";
        let a = Dns01Helper::txt_value(key_auth).unwrap();
        let b = DnsPersist01Helper::txt_value(key_auth).unwrap();
        assert_eq!(a, b);
    }

    #[tokio::test]
    async fn http01_solver_present_and_cleanup() {
        let solver = Http01Solver::new(0); // port 0 = unused for this test (no server started)
        solver.present("tok1", "tok1.thumb").await.unwrap();
        {
            let guard = solver.store.read().unwrap();
            assert_eq!(guard.get("tok1").map(String::as_str), Some("tok1.thumb"));
        }
        solver.cleanup("tok1").await.unwrap();
        {
            let guard = solver.store.read().unwrap();
            assert!(guard.get("tok1").is_none());
        }
    }

    #[test]
    fn tls_alpn01_solver_new_and_cleanup() {
        // cleanup on a solver that has never been started must not panic.
        let mut solver = TlsAlpn01Solver::new(0);
        solver.cleanup(); // handle is None — must be a no-op
    }
}
